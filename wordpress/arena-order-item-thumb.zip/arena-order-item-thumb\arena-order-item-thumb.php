<?php
/**
 * Plugin Name: Arena — תמונת הווריאציה במסך ההזמנה
 * Description: במסך עריכת ההזמנה מציג את תמונת הווריאציה שהוזמנה בפועל (הצבע) במקום תמונת מוצר האב, ומאפשר ללחוץ על התמונה כדי להגדיל אותה.
 * Version: 1.1.0
 * Author: COMAX AGENT
 * Requires Plugins: woocommerce
 *
 * ⚠️ הרקע: באתר פעיל התוסף `arena-parent-display` ("Arena - הצגת מוצר אב"),
 * שמחליף את הפריט בשורת ההזמנה במוצר האב — ולכן גם התמונה שמוצגת היא של
 * האב, לא של הצבע שהלקוח הזמין. הקוד הזה לא מבטל אותו; הוא רץ אחריו
 * (priority 9999) ומחזיר רק את התמונה לווריאציה הנכונה.
 *
 * ⚠️ אותו קובץ בדיוק מתאים גם להדבקה ב-Code Snippets — בלי בלוק ההערה הזה
 * ובלי `<?php`. לכן אין כאן `const` ברמת קובץ ואין `?>` באמצע: שניהם נשברים
 * בתוך ה-eval של Code Snippets, בעוד שקבוע מספרי ו-nowdoc עובדים בשתי הדרכים.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ⚠️ העטיפה הזאת אינה קישוט: אם הקוד יותקן גם כתוסף וגם כ-snippet, הצהרה
// כפולה של אותה פונקציה היא fatal שמפיל את כל האדמין.
if ( ! function_exists( 'arena_oit_thumbnail' ) ) :

	/**
	 * כמה צבעים יש למוצר האב — התשובה נשמרת, כי במסך הזמנה יש כמה שורות.
	 *
	 * ⚠️ זה מה שמבדיל תקלה ממצב תקין. מוצר **חד-צבעי** מציג את התמונה הראשית
	 * של האב לכל המידות, וזו בדיוק התמונה של הצבע היחיד — אין שם מה לתקן ואין
	 * על מה להתריע. נמדד 15/09/2026: מתוך 463 מוצרי אב באתר, 190 הם חד-צבעיים,
	 * ואזהרה עליהם הייתה הופכת את הסימון לרעש שאיש לא מסתכל עליו.
	 */
	function arena_oit_color_count( $product_id ) {
		static $cache = array();
		if ( isset( $cache[ $product_id ] ) ) {
			return $cache[ $product_id ];
		}
		$count  = 0;
		$parent = wc_get_product( $product_id );
		if ( $parent && $parent->is_type( 'variable' ) ) {
			$attrs = $parent->get_variation_attributes();
			foreach ( $attrs as $name => $options ) {
				if ( false !== stripos( $name, 'color' ) ) {
					$count = count( $options );
					break;
				}
			}
		}
		$cache[ $product_id ] = $count;
		return $count;
	}

	/**
	 * התמונה של שורת ההזמנה — של הווריאציה שהוזמנה, ועטופה בקישור להגדלה.
	 *
	 * ⚠️ הבדיקה היא `get_post_thumbnail_id` על הווריאציה ולא `$product->get_image()`:
	 * `WC_Product_Variation::get_image()` **נופל בשקט** לתמונת מוצר האב כשלווריאציה
	 * אין תמונה משלה, ולכן "חזרה תמונה" שם אינו אומר שהיא של הצבע הנכון. נמדד
	 * ב-15/09/2026 מול ה-REST: ווריאציה 74648 החזירה בדיוק את קובץ האב.
	 */
	function arena_oit_thumbnail( $thumbnail, $item_id, $item ) {
		if ( ! is_object( $item ) || ! method_exists( $item, 'get_variation_id' ) ) {
			return $thumbnail;
		}

		$variation_id = (int) $item->get_variation_id();
		$product_id   = (int) $item->get_product_id();

		$image_id  = $variation_id ? (int) get_post_thumbnail_id( $variation_id ) : 0;
		$is_actual = $image_id > 0;

		if ( ! $image_id ) {
			$image_id = (int) get_post_thumbnail_id( $product_id );
		}
		if ( ! $image_id ) {
			return $thumbnail; // אין תמונה בכלל — משאירים את מה שהיה
		}

		$img = wp_get_attachment_image(
			$image_id,
			'thumbnail',
			false,
			array(
				'title' => '',
				'alt'   => wp_strip_all_tags( $item->get_name() ),
				'class' => 'arena-oit-img',
			)
		);
		if ( ! $img ) {
			return $thumbnail;
		}

		$full = wp_get_attachment_image_url( $image_id, 'large' );
		if ( ! $full ) {
			$full = wp_get_attachment_image_url( $image_id, 'full' );
		}

		// מתריעים רק כשהתמונה באמת עלולה להטעות: אין לווריאציה תמונה משלה,
		// **ולמוצר יש יותר מצבע אחד**. בחד-צבעי תמונת האב היא הצבע הנכון.
		$ambiguous = ! $is_actual && arena_oit_color_count( $product_id ) > 1;

		// הכיתוב שמתחת להגדלה — שלוש שורות, מופרדות בשורה חדשה ומעוצבות ב-JS.
		// המטרה היא אימות פיזי: מי שמלקט מחזיק את הפריט ביד ומשווה. לכן זה
		// אינו שם הפריט הארוך אלא שלושת המזהים שמודפסים על המדבקה.
		$caption = implode( "\n", arena_oit_caption_lines( $item, $product_id, $variation_id, $ambiguous ) );

		// ⚠️ בלי תכונות data-* : הטמפלייט של WooCommerce מעביר את הפלט דרך
		// `wp_kses_post`, שמסנן data-* ומשאיר href/class/title. לכן הכתובת
		// המלאה יושבת ב-href, וה-JS קורא אותה משם.
		return sprintf(
			'<a href="%1$s" class="arena-oit-zoom%2$s" title="%3$s">%4$s</a>',
			esc_url( $full ),
			$ambiguous ? ' arena-oit-parent' : '',
			esc_attr( $caption ),
			$img
		);
	}
	/**
	 * שלוש שורות הכיתוב, לפי הסדר שבו המלקט קורא אותן.
	 *
	 * 1. **דגם-צבע-מידה** — המזהה שמודפס על המדבקה. הדגם מגיע מ-`_parent_sku`
	 *    (מספר הדגם בקומקס, למשל `004714`) ולא מ-ID של וורדפרס.
	 * 2. **שם המוצר במילים** — כדי שאפשר יהיה לזהות בלי לפענח קודים.
	 * 3. **הברקוד** — המזהה החד-משמעי היחיד, ונקרא ספרה-ספרה מול המדבקה.
	 *
	 * ⚠️ שמות הצבע והמידה נלקחים **כפי שהם באתר** ואינם מנורמלים לכתיב של
	 * קומקס. באתר הצבע הוא `102-SMOKE-SMOKE-BLACK` והמידה `One size`, בעוד
	 * שבקומקס אותו פריט הוא `102` ו-`Os`. נרמול היה ניחוש שעלול להצמיד את
	 * הכיתוב לפריט אחר — ולכן הברקוד, שזהה בשתי המערכות, הוא עוגן האימות.
	 */
	function arena_oit_caption_lines( $item, $product_id, $variation_id, $ambiguous ) {
		$lines   = array();
		$product = $variation_id ? wc_get_product( $variation_id ) : null;

		$model = '';
		if ( $product ) {
			$model = (string) $product->get_meta( '_parent_sku' );
		}
		if ( '' === $model ) {
			$parent = wc_get_product( $product_id );
			$model  = $parent ? (string) $parent->get_sku() : '';
		}

		// הצבע והמידה מהתכונות של הווריאציה, בשם המוצג ולא ב-slug.
		$parts = array();
		if ( $product && $product->is_type( 'variation' ) ) {
			foreach ( $product->get_attributes() as $taxonomy => $value ) {
				if ( '' === $value ) {
					continue;
				}
				if ( taxonomy_exists( $taxonomy ) ) {
					$term = get_term_by( 'slug', $value, $taxonomy );
					if ( $term && ! is_wp_error( $term ) ) {
						$value = $term->name;
					}
				}
				$parts[] = $value;
			}
		}

		$code = implode( '-', array_filter( array_merge( array( $model ), $parts ) ) );
		if ( '' !== $code ) {
			$lines[] = $code;
		}

		// שם המוצר במילים — הכותרת של מוצר האב, בלי הצבע והמידה שכבר בשורה 1.
		$title = get_the_title( $product_id );
		if ( $title ) {
			$lines[] = wp_strip_all_tags( $title );
		}

		// הברקוד. get_sku() של ווריאציה מחזיר את הברקוד שלה, ולא של האב.
		$sku = $product ? $product->get_sku() : '';
		if ( '' === $sku ) {
			$parent = wc_get_product( $product_id );
			$sku    = $parent ? $parent->get_sku() : '';
		}
		if ( '' !== $sku ) {
			$lines[] = $sku;
		}

		// נפילה לאחור: פריט בלי שום מזהה עדיף שיציג שם מאשר כלום.
		if ( ! $lines ) {
			$lines[] = wp_strip_all_tags( $item->get_name() );
		}

		if ( $ambiguous ) {
			$lines[] = '⚠ תמונת מוצר האב: לצבע הזה אין תמונה משלו, ייתכן שזה לא הצבע שהוזמן';
		}

		return $lines;
	}

	add_filter( 'woocommerce_admin_order_item_thumbnail', 'arena_oit_thumbnail', 9999, 3 );

	/** האם אנחנו במסך ההזמנה — גם בעורך הקלאסי וגם ב-HPOS. */
	function arena_oit_is_order_screen() {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return false;
		}
		$screen = get_current_screen();
		if ( ! $screen ) {
			return false;
		}
		if ( ! empty( $screen->post_type ) && 'shop_order' === $screen->post_type ) {
			return true;
		}
		return ! empty( $screen->id ) && false !== strpos( $screen->id, 'wc-orders' );
	}

	/**
	 * ההגדלה עצמה — CSS ו-JS ללא תלויות, ורק במסך ההזמנה.
	 *
	 * ⚠️ המאזין יושב על `document` ב-delegation ולא על התמונות עצמן, כי
	 * WooCommerce טוען מחדש את טבלת הפריטים ב-AJAX אחרי כל עריכה — מאזין
	 * שנקשר לתמונה מת שם, וההגדלה הייתה מפסיקה לעבוד בלי שום שגיאה.
	 */
	function arena_oit_footer() {
		if ( ! arena_oit_is_order_screen() ) {
			return;
		}

		echo <<<'HTML'
<style id="arena-oit-css">
/* התמונה בשורה — מעט גדולה מ-38px של WooCommerce, כדי שהצבע יהיה קריא בלי לחיצה */
.woocommerce_order_items .wc-order-item-thumbnail { width: 48px; height: 48px; }
.woocommerce_order_items td.thumb { width: 48px; }
.arena-oit-zoom { display: block; cursor: zoom-in; line-height: 0; }
.arena-oit-zoom img { width: 100%; height: auto; border-radius: 3px; }
/* מסגרת כתומה מקווקוות = אין תמונה לווריאציה, ומה שנראה הוא האב */
.arena-oit-zoom.arena-oit-parent img { outline: 2px dashed #d98500; outline-offset: -2px; }
.arena-oit-overlay {
	position: fixed; inset: 0; z-index: 160000; background: rgba(0,0,0,.82);
	display: flex; align-items: center; justify-content: center;
	padding: 24px; cursor: zoom-out;
}
.arena-oit-overlay figure { margin: 0; text-align: center; }
.arena-oit-overlay img { max-width: min(88vw, 900px); max-height: 80vh; background: #fff; border-radius: 4px; }
.arena-oit-overlay figcaption {
	color: #fff; margin-top: 14px; direction: rtl; max-width: 88vw;
}
/* שלוש שורות בהיררכיה: הקוד גדול, השם רגיל, הברקוד רחב ומרווח לקריאה ספרה-ספרה. */
.arena-oit-overlay .arena-oit-cap-code {
	font-size: 22px; font-weight: 700; letter-spacing: .5px; direction: ltr;
}
.arena-oit-overlay .arena-oit-cap-name { font-size: 15px; margin-top: 4px; opacity: .92; }
.arena-oit-overlay .arena-oit-cap-barcode {
	font-family: Consolas, "Courier New", monospace; font-size: 20px; letter-spacing: 3px;
	direction: ltr; margin-top: 8px; padding: 4px 10px; display: inline-block;
	background: rgba(255,255,255,.12); border-radius: 4px;
}
.arena-oit-overlay .arena-oit-cap-warn {
	font-size: 14px; margin-top: 10px; color: #ffd08a;
}
.arena-oit-overlay .arena-oit-close {
	position: absolute; top: 14px; inset-inline-end: 18px; color: #fff;
	font-size: 32px; line-height: 1; background: none; border: 0; cursor: pointer;
}
</style>
<script id="arena-oit-js">
(function () {
	var overlay = null;

	function close() {
		if (overlay) { overlay.remove(); overlay = null; }
	}

	function open(src, caption) {
		close();
		overlay = document.createElement('div');
		overlay.className = 'arena-oit-overlay';

		var btn = document.createElement('button');
		btn.className = 'arena-oit-close';
		btn.type = 'button';
		btn.setAttribute('aria-label', 'סגירה');
		btn.textContent = '×';

		var fig = document.createElement('figure');
		var img = document.createElement('img');
		img.setAttribute('src', src);
		img.setAttribute('alt', caption || '');
		var cap = document.createElement('figcaption');
		// הכיתוב מגיע כשורות מופרדות בשורה חדשה מתוך title, ומקבל מחלקה לפי תפקידו:
		// קוד, שם, ברקוד, ואזהרה. textContent בכל שורה — לא innerHTML.
		var lines = String(caption || '').split('\n').filter(function (t) { return t !== ''; });
		var classes = ['arena-oit-cap-code', 'arena-oit-cap-name', 'arena-oit-cap-barcode'];
		var slot = 0;
		lines.forEach(function (text) {
			var row = document.createElement('div');
			if (text.charAt(0) === '⚠') {
				row.className = 'arena-oit-cap-warn';
			} else {
				row.className = classes[slot] || 'arena-oit-cap-name';
				slot++;
			}
			row.textContent = text;
			cap.appendChild(row);
		});

		fig.appendChild(img);
		fig.appendChild(cap);
		overlay.appendChild(btn);
		overlay.appendChild(fig);
		document.body.appendChild(overlay);
	}

	document.addEventListener('click', function (e) {
		var t = e.target;
		if (!t || !t.closest) { return; }
		var link = t.closest('a.arena-oit-zoom');
		if (link) {
			e.preventDefault();
			open(link.getAttribute('href'), link.getAttribute('title'));
			return;
		}
		if (overlay && t.closest('.arena-oit-overlay')) { close(); }
	});

	document.addEventListener('keydown', function (e) {
		if (e.key === 'Escape') { close(); }
	});
})();
</script>
HTML;
	}
	add_action( 'admin_footer', 'arena_oit_footer' );

endif;
